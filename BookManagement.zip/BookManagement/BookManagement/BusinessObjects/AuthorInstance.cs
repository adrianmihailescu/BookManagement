﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BookManagement.BusinessObjects
{
    public class AuthorInstance
    {
        public int IDAuthor;
        public string AuthorName;
        public bool? FlagDel;
    }
}